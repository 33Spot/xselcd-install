/*
 * X Selection-Clear Daemon; Public Domain, 2019.
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <unistd.h>

#include <X11/Xlib.h>
#include <X11/Xatom.h>

void usage(FILE *stream)
{
	fputs(	"\n"											\
		"Usage: xselcd [-h] [-d <display>] [-t <seconds>]\n"					\
		"\n"											\
		"User daemon to automatically clear the PRIMARY, SECONDARY and CLIPBOARD X\n"		\
		"selections a configurable number of seconds from their selection.\n"			\
		"\n"											\
		"  -h		 : This usage screen\n"							\
		"  -d <display>  : The X display (default from the DISPLAY environment variable)\n"	\
		"  -t <seconds>  : The clearing interval in seconds (default 10)\n"			\
		"\n", stream);
}

volatile sig_atomic_t term;

void sigterm(int signum __attribute__((unused)))
{
	term = 1;
}

int main(int argc, char *argv[])
{
	int   c;
	char *s;

	char *display_name = NULL;

	unsigned seconds = 10;
	unsigned remains;

	Display *display;
	Atom	 xa_clipboard;

	struct sigaction action;

	int screen;
	unsigned long border;
	Window w;
	XEvent event;

	while ((c = getopt(argc, argv, "d:ht:")) != -1)
		switch (c) {
		case 'd':
			display_name = optarg;
			break;
		case 'h':
			usage(stdout);
			return EXIT_SUCCESS;
		case 't':
			errno = 0;
			seconds = strtol(optarg, &s, 0);
			if (!errno && !*s && 0 < seconds && seconds <= UINT_MAX / 1000)
				break;
			__attribute__ ((fallthrough));
		case '?':
			usage(stderr);
			return EXIT_FAILURE;
		}

	display = XOpenDisplay(display_name);
	if (!display) {
		fputs("Could not open display\n", stderr);
		return EXIT_FAILURE;
	}
	xa_clipboard = XInternAtom(display, "CLIPBOARD", False);

	action.sa_handler = sigterm;
	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;
	if (sigaction(SIGTERM, &action, NULL) == -1) {
		perror("Could not install handler");
		return EXIT_FAILURE;
	}

	screen = DefaultScreen(display);
	border = BlackPixel(display, screen);
	w = XCreateSimpleWindow(display, RootWindow(display, screen), 0, 0, 1, 1, 0, border, border);
	XSelectInput(display, w, PropertyChangeMask);

	for (remains = seconds; !term; remains = sleep(remains)) {
		/* obtain current X server time */
		XChangeProperty(display, w, XA_WM_NAME, XA_STRING, 8, PropModeAppend, NULL, 0);
		do {
			XNextEvent(display, &event);
		} while (event.type != PropertyNotify);

		/* underflow (and rollover) okay */
		event.xproperty.time -= 1000 * seconds;

		XSetSelectionOwner(display, XA_PRIMARY, None, event.xproperty.time);
		XSetSelectionOwner(display, XA_SECONDARY, None, event.xproperty.time);
		XSetSelectionOwner(display, xa_clipboard, None, event.xproperty.time);
		XSync(display, False);

		if (!remains)
			remains = seconds;
	}

	XDestroyWindow(display, w);
	XCloseDisplay(display);
	return EXIT_SUCCESS;
}
